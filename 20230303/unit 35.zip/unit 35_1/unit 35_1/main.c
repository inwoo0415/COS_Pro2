#include <stdio.h>

int main()
{
	char c1 = 'a';
	char* s1 = "Hello";

	printf("%c\n", c1);
	printf("%s\n", s1);

	return 0;
}