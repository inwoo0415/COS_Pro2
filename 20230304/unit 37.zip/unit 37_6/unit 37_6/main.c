#include <stdio.h>
#include <string.h>

int main()
{
	char* s1 = "C Language";

	printf("%d\n", strlen(s1));

	return 0; 

}
	